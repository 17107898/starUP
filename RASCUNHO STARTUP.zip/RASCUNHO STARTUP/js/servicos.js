// Função para abrir o modal de contato
function contactPrestador(prestadorName, serviceName) {
    document.getElementById('prestadorName').textContent = prestadorName;
    document.getElementById('serviceName').textContent = serviceName;
    document.getElementById('contactModal').style.display = 'block';
}

// Função para fechar o modal de contato
function closeModal() {
    document.getElementById('contactModal').style.display = 'none';
}
