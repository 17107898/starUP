function openTab(tabName) {
    // Esconde todos os conteúdos de abas
    const tabContents = document.getElementsByClassName('tabcontent');
    for (let i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = 'none';
    }

    // Mostra o conteúdo da aba selecionada
    document.getElementById(tabName).style.display = 'block';
}

// Exibe o perfil por padrão ao abrir o dashboard
openTab('perfil');
