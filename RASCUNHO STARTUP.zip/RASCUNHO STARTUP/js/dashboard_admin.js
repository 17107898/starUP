function mostrarClientes() {
    document.getElementById('content').innerHTML = '<h3>Clientes</h3><div id="listaClientes"></div>';
    // Aqui você deve carregar a lista de clientes do banco de dados e exibi-los
}

function mostrarPrestadores() {
    document.getElementById('content').innerHTML = '<h3>Prestadores de Serviços</h3><div id="listaPrestadores"></div>';
    // Aqui você deve carregar a lista de prestadores do banco de dados e exibi-los
}

function mostrarServicos() {
    document.getElementById('content').innerHTML = '<h3>Serviços</h3><div id="listaServicos"></div>';
    // Aqui você deve carregar a lista de serviços do banco de dados e exibi-los
}

function mostrarClientes() {
    document.getElementById('content').innerHTML = '<h3>Clientes</h3><div id="listaClientes"></div>';
    
    // Simulação de clientes (em um caso real, isso viria do banco de dados)
    const clientes = [
        { id: 1, email: "cliente1@example.com" },
        { id: 2, email: "cliente2@example.com" }
    ];

    const listaClientes = document.getElementById('listaClientes');
    clientes.forEach(cliente => {
        const div = document.createElement('div');
        div.innerHTML = `
            <p>${cliente.email} <button onclick="excluirCliente(${cliente.id})">Excluir</button></p>
        `;
        listaClientes.appendChild(div);
    });
}

function excluirCliente(id) {
    alert(`Cliente com ID ${id} excluído com sucesso!`);
    // Aqui você deve implementar a lógica para excluir o cliente do banco de dados
}

function mostrarPrestadores() {
    document.getElementById('content').innerHTML = '<h3>Prestadores de Serviços</h3><div id="listaPrestadores"></div>';

    // Simulação de prestadores (em um caso real, isso viria do banco de dados)
    const prestadores = [
        { id: 1, email: "prestador1@example.com", servico: "Serviço A" },
        { id: 2, email: "prestador2@example.com", servico: "Serviço B" }
    ];

    const listaPrestadores = document.getElementById('listaPrestadores');
    prestadores.forEach(prestador => {
        const div = document.createElement('div');
        div.innerHTML = `
            <p>${prestador.email} - ${prestador.servico} <button onclick="excluirPrestador(${prestador.id})">Excluir</button></p>
        `;
        listaPrestadores.appendChild(div);
    });
}

function excluirPrestador(id) {
    alert(`Prestador com ID ${id} excluído com sucesso!`);
    // Aqui você deve implementar a lógica para excluir o prestador do banco de dados
}
