// Função para simular armazenamento (pode ser adaptada para fazer requisição a um servidor)
const clientes = [];
const prestadores = [];

// Cadastro de Cliente
document.getElementById('formCliente').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita envio padrão do formulário
    const email = document.getElementById('clienteEmail').value;
    const number = document.getElementById('ClienteTelefone').value;
    const password = document.getElementById('clienteSenha').value;

    // Armazena o cliente (ou envia ao backend)
    clientes.push({ email: email, telefone:number, password: password });

    alert('Cliente cadastrado com sucesso!');
    console.log('Clientes:', clientes);

    // Limpa o formulário
    document.getElementById('formCliente').reset();
});

// Cadastro de Prestador de Serviços
document.getElementById('formPrestador').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita envio padrão do formulário
    const email = document.getElementById('prestadorEmail').value;
    const number = document.getElementById('prestadorTelefone').value;
    const password = document.getElementById('senhaPrestador').value;

    // Armazena o prestador (ou envia ao backend)
    prestadores.push({ email: email, telefone:number, password: password });

    alert('Prestador de serviços cadastrado com sucesso!');
    console.log('Prestadores:', prestadores);

    // Limpa o formulário
    document.getElementById('formPrestador').reset();
});