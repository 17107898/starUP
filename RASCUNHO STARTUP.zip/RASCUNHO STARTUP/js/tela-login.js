function openLogin(loginType) {
    // Esconde ambos os formulários
    document.getElementById('cliente').style.display = 'none';
    document.getElementById('prestador').style.display = 'none';

    // Exibe o formulário selecionado
    document.getElementById(loginType).style.display = 'block';
}

// Exibe o formulário de cliente por padrão
openLogin('cliente');

// LOGIN CLIENTE //
document.getElementById("clienteLoginForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Evita o envio padrão do formulário

    // Simula a validação do login (substitua por validação real)
    const email = document.getElementById("emailCliente").value;
    const password = document.getElementById("senhaCliente").value;

    if (email === "cliente@example.com" && password === "123456") {
        // Login bem-sucedido, redirecionar para o dashboard
        window.location.href = "dashboard-cliente.html";  // Redireciona para o dashboard
    } else {
        alert("E-mail ou senha incorretos.");
    }
});

// LOGIN PRESTADOR //
document.getElementById("prestadorLoginForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Evita o envio padrão do formulário

    // Simula a validação do login (substitua por validação real)
    const email = document.getElementById("emailPrestador").value;
    const password = document.getElementById("senhaPrestador").value;

    if (email === "cliente@example.com" && password === "123456") {
        // Login bem-sucedido, redirecionar para o dashboard
        window.location.href = "dashboard-prestador.html";  // Redireciona para o dashboard
    } else {
        alert("E-mail ou senha incorretos.");
    }
});