 // Simulação de login do administrador
 document.getElementById('loginAdmin').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita envio padrão do formulário
    const email = document.getElementById('adminEmail').value;
    const password = document.getElementById('adminPassword').value;

    // Verifica credenciais do administrador (substitua com lógica real)
    if (email === "admin@example.com" && password === "admin123") {
        alert("Login bem-sucedido! Redirecionando ao painel.");
        window.location.href = "dashboard_admin.html"; // Redireciona para o painel do administrador
    } else {
        alert("E-mail ou senha incorretos. Tente novamente.");
    }
});