<?php
// Conexão com o banco de dados (substitua pelos seus dados)
$conn = new mysqli("localhost", "usuario_db", "senha_db", "nome_do_banco");

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $service = $_POST['service'];

    // Insere o prestador de serviços no banco de dados
    $sql = "INSERT INTO prestadores (email, password, service) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $email, $password, $service);

    if ($stmt->execute()) {
        echo "Prestador de serviços cadastrado com sucesso!";
    } else {
        echo "Erro ao cadastrar prestador: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
