<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Usuários</title>
</head>
<body>
    <h2>Cadastro de Cliente</h2>
    <form method="post" action="cadastro_cliente.php">
        <label for="clienteEmail">E-mail:</label>
        <input type="email" id="clienteEmail" name="email" required><br><br>
        <label for="clientePassword">Senha:</label>
        <input type="password" id="clientePassword" name="password" required><br><br>
        <button type="submit">Cadastrar Cliente</button>
    </form>

    <h2>Cadastro de Prestador de Serviços</h2>
    <form method="post" action="cadastro_prestador.php">
        <label for="prestadorEmail">E-mail:</label>
        <input type="email" id="prestadorEmail" name="email" required><br><br>
        <label for="prestadorPassword">Senha:</label>
        <input type="password" id="prestadorPassword" name="password" required><br><br>
        <label for="serviceOffered">Serviço Oferecido:</label>
        <input type="text" id="serviceOffered" name="service" required><br><br>
        <button type="submit">Cadastrar Prestador</button>
    </form>
</body>
</html>
